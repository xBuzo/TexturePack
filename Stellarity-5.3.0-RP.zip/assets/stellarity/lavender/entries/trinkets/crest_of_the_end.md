```json
{
  "title": "Tamaris",
  "icon": "minecraft:stick[item_model=\"stellarity:tamaris\"]",
  "category": "stellarity:weapons",
  "associated_items": []
}
```

![Tamaris](stellarity:textures/item/tamaris.png,fit)

;;;;;

