```json
{
  "title": "Armors",
  "icon": "minecraft:stick[item_model=\"stellarity:shulker_chestplate\"]"
}
```
